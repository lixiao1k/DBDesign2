CREATE TRIGGER updateServertime
AFTER INSERT ON record
FOR EACH ROW
  BEGIN     UPDATE bike b SET b.servertime = b.servertime + (TIMESTAMPDIFF(MINUTE,NEW.starttime,NEW.endtime)/30) WHERE b.bid = NEW.bid;   END;
