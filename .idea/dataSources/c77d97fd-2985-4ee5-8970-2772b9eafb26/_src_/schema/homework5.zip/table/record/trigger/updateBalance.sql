CREATE TRIGGER updateBalance
AFTER INSERT ON record
FOR EACH ROW
  BEGIN     UPDATE user u SET u.balance = u.balance - NEW.cost WHERE u.uid = NEW.uid;   END;
